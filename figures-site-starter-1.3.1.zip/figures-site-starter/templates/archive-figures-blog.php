<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
global $wp_query;
get_header();
?>
<!-- Figures blog archive: paper-and-Gosu-blue editorial layout, scoped to this custom post type only. -->
<main id="primary" class="figures-blog-page">
	<div class="figures-blog-site">
		<header class="figures-blog-masthead">
			<aside class="figures-blog-rail" aria-hidden="true"><span>FIGURES / BLOG</span><b>01</b></aside>
			<div class="figures-blog-masthead-copy"><p>FIGURES / BLOG</p><h1>ブログ</h1><span>ESSAYS &amp; NOTES</span></div>
		</header>
		<section class="figures-blog-listing" aria-labelledby="figures-blog-list-title">
			<aside class="figures-blog-index" aria-hidden="true"><b>02</b><span>INDEX</span></aside>
			<div class="figures-blog-listing-main"><div class="figures-blog-listing-head"><p id="figures-blog-list-title">ARTICLE INDEX</p><span><?php echo esc_html( (string) $wp_query->found_posts ); ?> ARTICLES</span></div>
			<?php if ( have_posts() ) : ?><div class="figures-blog-list">
				<?php while ( have_posts() ) : the_post(); ?><article class="figures-blog-list-item"><a href="<?php the_permalink(); ?>"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'Y.m.d' ) ); ?></time><h2><?php the_title(); ?></h2><span aria-hidden="true">→</span></a></article><?php endwhile; ?>
			</div><?php the_posts_pagination( array( 'mid_size' => 1, 'prev_text' => '← 新しい記事', 'next_text' => '古い記事 →' ) ); ?>
			<?php else : ?><div class="figures-blog-empty"><p>現在、公開中の記事はありません。</p><span>記事が公開されると、このページに日付順で掲載されます。</span></div><?php endif; ?>
			</div>
		</section>
		<footer class="figures-blog-return"><a href="<?php echo esc_url( home_url( '/figures/' ) ); ?>">Figures トップへ　→</a></footer>
	</div>
</main>
<?php get_footer(); ?>
