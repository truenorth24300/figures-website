<?php
/**
 * Figures landing page.
 *
 * This template deliberately omits the corporate theme's get_sidebar() call.
 * The company header and footer remain in place, while the editorial layout
 * receives the width required by the two-page issue spreads.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

get_header();

while ( have_posts() ) :
	the_post();
	?>
	<main id="primary" class="figures-page-shell" role="main">
		<?php echo do_shortcode( get_post_field( 'post_content', get_the_ID() ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</main>
	<?php
endwhile;

get_footer();
