<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) : the_post();
	$pdf = get_post_meta( get_the_ID(), '_figures_pdf_url', true );
?>
<main class="figures-article"><p class="figures-article-meta"><?php echo esc_html( figures_starter_issue_date( get_the_ID() ) ); ?>　<?php echo esc_html( get_post_meta( get_the_ID(), '_figures_number', true ) ); ?></p><h1><?php the_title(); ?></h1><div class="figures-spread"><figure><figcaption>表紙</figcaption><?php echo wp_kses_post( figures_starter_issue_folio( get_the_ID(), 'cover' ) ); ?></figure><figure><figcaption>目次</figcaption><?php echo wp_kses_post( figures_starter_issue_folio( get_the_ID(), 'toc' ) ); ?></figure></div><?php if ( $pdf ) : ?><p><a class="figures-link" target="_blank" rel="noopener" href="<?php echo esc_url( $pdf ); ?>">PDFを開く　→</a></p><?php endif; ?></main>
<?php endwhile; get_footer(); ?>
