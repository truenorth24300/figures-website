<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) : the_post();
?>
<!-- Figures blog entry: anonymous author presentation within the same editorial system as the archive. -->
<main id="primary" class="figures-blog-page">
	<div class="figures-blog-site figures-blog-entry-site">
		<header class="figures-blog-entry-head"><aside class="figures-blog-rail" aria-hidden="true"><span>FIGURES / BLOG</span><b>01</b></aside><div><p>FIGURES / BLOG</p><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'Y.m.d' ) ); ?></time><h1><?php the_title(); ?></h1></div></header>
		<article class="figures-blog-entry"><aside class="figures-blog-index" aria-hidden="true"><b>02</b><span>ESSAY</span></aside><div class="figures-blog-entry-body"><?php the_content(); ?></div></article>
		<footer class="figures-blog-return"><a href="<?php echo esc_url( get_post_type_archive_link( 'figures_blog' ) ); ?>">ブログ一覧へ　→</a><a href="<?php echo esc_url( home_url( '/figures/' ) ); ?>">Figures トップへ　→</a></footer>
	</div>
</main>
<?php endwhile; get_footer(); ?>
