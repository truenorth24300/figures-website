# Figures Site Starter 1.2.0

## 目的

このプラグインは、デジタルリサーチ社の既存WordPressテーマを変更せず、`/figures/` 配下に文芸誌Figuresの専用ページと管理画面を追加します。FiguresのCSSは `.figures-site` 以下に限定され、会社サイトの既存ページには適用されません。

## 収録する機能

| 機能 | 管理画面で行うこと |
|---|---|
| 最新号・バックナンバー | 号名、号数、発行日、表紙、目次画像、公開PDF、最新号フラグを登録します。 |
| 無署名ブログ | 角谷氏・遠藤氏が個別アカウントで日付・タイトル・本文を投稿します。公開側に投稿者名は出ません。 |
| 通信欄 | Contact Form 7のショートコードを設定します。受信先はContact Form 7の設定にだけ保存します。 |
| 公開デザイン | 背景は淡い紙色、アクセントは呉須青 `#17476C` です。 |

## 導入前の確認

1. 本番サイトのファイルとデータベースのバックアップを取得します。
2. 既存サイトに `/figures/`、`/figures/issue/`、`/figures/blog/`、`/figures/backnumber/` が使われていないことを確認します。
3. 既存テーマを直接編集しません。テーマファイルエディターも使用しません。
4. Contact Form 7が未導入の場合は、技術管理者が先に導入します。

## 導入手順

1. このフォルダを `figures-site-starter-1.2.0.zip` として圧縮します。
2. WordPress管理画面の **プラグイン → 新規プラグインを追加 → プラグインのアップロード** でZIPをアップロードし、有効化します。
3. 固定ページ `/figures/` が作成され、本文に `[figures_home]` が入っていることを確認します。
4. **Figures 運用 → 通信欄** を開き、作成したContact Form 7のショートコードを保存します。
5. Contact Form 7側で受信先 `landsendlive@gmail.com`、Reply-To `[your-email]`、確認用語句 `Figures` を設定します。送信先アドレスを公開本文やGitHubへ記載しません。
6. **ユーザー → 新規ユーザーを追加** から角谷氏・遠藤氏の個別アカウントを作り、権限を **Figures投稿者** にします。
7. **Figures 運用 → 号を管理** から第1〜4号を登録します。各号の表紙、目次画像、PDFの公開可否は事務局が確認します。
8. PC、スマートフォン、PDF表示、フォーム受信を確認します。

## 通信欄のフォーム例

```text
お名前（必須） [text* your-name]
E-mail（必須） [email* your-email]
通信内容の種類 [select inquiry-type "冊子の希望" "Figuresについて" "その他"]
件名 [text your-subject]
通信内容（必須） [textarea* your-message]
確認のため「Figures」と入力してください。 [text* figures-check]
[submit "内容を確認して送信 →"]
```

Contact Form 7の追加設定で、`[figures-check]` が `Figures` と一致しない場合は送信を拒否する確認ロジックを設定してください。実装時には送受信テストを行います。

## 保守

プラグイン更新は、必ずローカルでPHP構文とZIP内容を確認後、版番号を上げたZIPとして配布します。WordPressのテーマファイルエディターで直接編集しません。AIOSEOを利用している場合は、SEOタイトル、description、OGP、Xカードの出力をAIOSEOだけに統一します。
