<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) : the_post();
?>
<main class="figures-article">
	<p class="figures-article-meta"><?php echo esc_html( get_the_date( 'Y.m.d' ) ); ?></p>
	<h1><?php the_title(); ?></h1>
	<div class="figures-article-body"><?php the_content(); ?></div>
	<p><a class="figures-link" href="<?php echo esc_url( get_post_type_archive_link( 'figures_blog' ) ); ?>">ブログ一覧へ　→</a></p>
</main>
<?php endwhile; get_footer(); ?>
