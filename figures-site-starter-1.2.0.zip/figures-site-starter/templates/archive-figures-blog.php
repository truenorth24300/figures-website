<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<main class="figures-blog-archive"><p class="figures-article-meta">FIGURES / BLOG</p><h1>ブログ</h1>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
	<article><a href="<?php the_permalink(); ?>"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'Y.m.d' ) ); ?></time><span><?php the_title(); ?></span></a></article>
<?php endwhile; the_posts_pagination(); else : ?><p>ブログ記事はまだありません。</p><?php endif; ?>
</main>
<?php get_footer(); ?>
