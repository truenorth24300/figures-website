<?php
/**
 * Plugin Name: Figures Site Starter
 * Description: 文芸誌 Figures の最新号・バックナンバー・お知らせを、分かりやすい専用画面で管理するための初期コンテナです。
 * Version: 1.0.0
 * Author: Digital Research / Figures
 * Text Domain: figures-site-starter
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'FIGURES_STARTER_VERSION', '1.0.0' );
define( 'FIGURES_STARTER_PATH', plugin_dir_path( __FILE__ ) );
define( 'FIGURES_STARTER_URL', plugin_dir_url( __FILE__ ) );

/**
 * Registers content types separately from the theme, so editorial data survives a theme change.
 */
function figures_starter_register_content_types() {
	register_post_type(
		'figures_issue',
		array(
			'labels' => array(
				'name' => 'Figures号',
				'singular_name' => 'Figures号',
				'add_new' => '新しい号を追加',
				'add_new_item' => 'Figures号を追加',
				'edit_item' => 'Figures号を編集',
				'new_item' => '新しい号',
				'view_item' => '公開ページを表示',
				'search_items' => 'Figures号を検索',
				'not_found' => 'Figures号はまだありません',
				'menu_name' => 'Figures号',
			),
			'public' => true,
			'show_ui' => true,
			'show_in_menu' => false,
			'show_in_rest' => true,
			'has_archive' => 'figures/issues',
			'rewrite' => array( 'slug' => 'figures/issue', 'with_front' => false ),
			'menu_icon' => 'dashicons-book-alt',
			'supports' => array( 'title', 'thumbnail', 'revisions' ),
			'capability_type' => array( 'figures_issue', 'figures_issues' ),
			'map_meta_cap' => true,
		)
	);

	register_post_type(
		'figures_news',
		array(
			'labels' => array(
				'name' => 'Figures お知らせ',
				'singular_name' => 'お知らせ',
				'add_new' => 'お知らせを追加',
				'add_new_item' => 'お知らせを追加',
				'edit_item' => 'お知らせを編集',
				'new_item' => '新しいお知らせ',
				'view_item' => '公開ページを表示',
				'not_found' => 'お知らせはまだありません',
				'menu_name' => 'Figures お知らせ',
			),
			'public' => true,
			'show_ui' => true,
			'show_in_menu' => false,
			'show_in_rest' => true,
			'has_archive' => 'figures/news',
			'rewrite' => array( 'slug' => 'figures/news', 'with_front' => false ),
			'menu_icon' => 'dashicons-megaphone',
			'supports' => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions' ),
			'capability_type' => array( 'figures_news', 'figures_news_items' ),
			'map_meta_cap' => true,
		)
	);

	register_taxonomy(
		'figures_news_type',
		array( 'figures_news' ),
		array(
			'labels' => array( 'name' => 'お知らせの種類', 'singular_name' => 'お知らせの種類' ),
			'public' => false,
			'show_ui' => true,
			'show_in_rest' => true,
		)
	);
}
add_action( 'init', 'figures_starter_register_content_types' );

/**
 * Creates an editor role limited to Figures content and gives technical administrators full access.
 */
function figures_starter_add_roles_and_capabilities() {
	$types = array( 'figures_issues', 'figures_news_items' );
	$base_caps = array( 'read' => true, 'upload_files' => true );

	foreach ( $types as $type ) {
		$singular = rtrim( $type, 's' );
		$base_caps[ 'edit_' . $type ] = true;
		$base_caps[ 'publish_' . $type ] = true;
		$base_caps[ 'delete_' . $type ] = true;
		$base_caps[ 'edit_published_' . $type ] = true;
		$base_caps[ 'delete_published_' . $type ] = true;
		$base_caps[ 'read_private_' . $type ] = true;
		$base_caps[ 'edit_private_' . $type ] = true;
		$base_caps[ 'delete_private_' . $type ] = true;
		$base_caps[ 'edit_' . $singular ] = true;
		$base_caps[ 'read_' . $singular ] = true;
		$base_caps[ 'delete_' . $singular ] = true;
	}

	add_role( 'figures_editor', 'Figures編集者', $base_caps );

	$admin = get_role( 'administrator' );
	if ( $admin ) {
		foreach ( $base_caps as $capability => $granted ) {
			$admin->add_cap( $capability, $granted );
		}
		foreach ( $types as $type ) {
			$admin->add_cap( 'edit_others_' . $type, true );
			$admin->add_cap( 'delete_others_' . $type, true );
			$admin->add_cap( 'read_private_' . $type, true );
		}
	}
}

/**
 * Installs the public home page without overwriting an existing Figures page.
 */
function figures_starter_activate() {
	figures_starter_register_content_types();
	figures_starter_add_roles_and_capabilities();

	if ( ! get_page_by_path( 'figures' ) ) {
		wp_insert_post(
			array(
				'post_title' => 'Figures',
				'post_name' => 'figures',
				'post_status' => 'publish',
				'post_type' => 'page',
				'post_content' => '[figures_home]',
			)
		);
	}
	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'figures_starter_activate' );

function figures_starter_deactivate() {
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'figures_starter_deactivate' );

/**
 * A compact Figures operation menu gives non-technical editors a safe, predictable entry point.
 */
function figures_starter_admin_menu() {
	add_menu_page(
		'Figures 運用',
		'Figures 運用',
		'edit_figures_issues',
		'figures-operation',
		'figures_starter_render_operation_page',
		'dashicons-book-alt',
		25
	);
	add_submenu_page( 'figures-operation', '運用の概要', '運用の概要', 'edit_figures_issues', 'figures-operation', 'figures_starter_render_operation_page' );
	add_submenu_page( 'figures-operation', '最新号を更新', '最新号を更新', 'edit_figures_issues', 'edit.php?post_type=figures_issue' );
	add_submenu_page( 'figures-operation', 'バックナンバー', 'バックナンバー', 'edit_figures_issues', 'edit.php?post_type=figures_issue&figures_view=archive' );
	add_submenu_page( 'figures-operation', 'お知らせ', 'お知らせ', 'edit_figures_news_items', 'edit.php?post_type=figures_news' );
	add_submenu_page( 'figures-operation', 'お問い合わせ設定', 'お問い合わせ設定', 'edit_figures_issues', 'figures-contact-help', 'figures_starter_render_contact_help' );
	add_submenu_page( 'figures-operation', '操作説明', '操作説明', 'edit_figures_issues', 'figures-operation-help', 'figures_starter_render_operation_help' );
}
add_action( 'admin_menu', 'figures_starter_admin_menu' );

function figures_starter_render_operation_page() {
	if ( ! current_user_can( 'edit_figures_issues' ) ) {
		return;
	}
	$issues = wp_count_posts( 'figures_issue' );
	$news = wp_count_posts( 'figures_news' );
	$current = figures_starter_get_current_issue();
	?>
	<div class="wrap figures-admin-wrap">
		<h1>Figures 運用</h1>
		<p class="description">この画面から、日常の更新に必要な場所だけを開けます。設定やプラグインの変更は、技術管理者が行ってください。</p>
		<div class="figures-admin-cards">
			<a class="figures-admin-card" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=figures_issue' ) ); ?>"><span class="dashicons dashicons-book-alt"></span><strong>最新号を登録</strong><small>表紙、号情報、目次を入力</small></a>
			<a class="figures-admin-card" href="<?php echo esc_url( admin_url( 'edit.php?post_type=figures_issue' ) ); ?>"><span class="dashicons dashicons-archive"></span><strong>バックナンバー</strong><small><?php echo esc_html( (int) $issues->publish ); ?>件を公開中</small></a>
			<a class="figures-admin-card" href="<?php echo esc_url( admin_url( 'edit.php?post_type=figures_news' ) ); ?>"><span class="dashicons dashicons-megaphone"></span><strong>お知らせ</strong><small><?php echo esc_html( (int) $news->publish ); ?>件を公開中</small></a>
			<a class="figures-admin-card" href="<?php echo esc_url( admin_url( 'admin.php?page=figures-contact-help' ) ); ?>"><span class="dashicons dashicons-email-alt"></span><strong>お問い合わせ設定</strong><small>受信先とフォームを確認</small></a>
		</div>
		<div class="figures-admin-notice">
			<h2>現在の公開状態</h2>
			<?php if ( $current ) : ?>
				<p><strong>最新号：</strong><?php echo esc_html( get_the_title( $current->ID ) ); ?>。公開ページは <a href="<?php echo esc_url( get_permalink( get_page_by_path( 'figures' ) ) ); ?>" target="_blank" rel="noopener">/figures/</a> で確認できます。</p>
			<?php else : ?>
				<p><strong>最新号は未登録です。</strong>「最新号を登録」から最初の一冊を下書きとして登録してください。公開後に「最新号として表示」をオンにすると、トップページに表示されます。</p>
			<?php endif; ?>
		</div>
	</div>
	<?php
}

function figures_starter_render_contact_help() {
	?>
	<div class="wrap figures-admin-wrap"><h1>お問い合わせ設定</h1>
		<p>お問い合わせフォームは、現在利用しているフォーム機能を使うか、Contact Form 7などのフォームプラグインを技術管理者が設定します。</p>
		<ol><li>受信先には個人メールアドレスではなく、引継ぎ可能な編集部用メールアドレスを設定します。</li><li>氏名、メールアドレス、件名、内容、個人情報取扱いへの同意をフォームに設定します。</li><li>公開前に実際の送受信テストを行い、迷惑メールフォルダも確認します。</li><li>フォームのショートコードを「Figures」固定ページの指定箇所に追加します。</li></ol>
	</div>
	<?php
}

function figures_starter_render_operation_help() {
	?>
	<div class="wrap figures-admin-wrap"><h1>操作説明</h1>
		<h2>新号を公開する手順</h2>
		<ol><li>「最新号を更新」から「新しい号を追加」を押します。</li><li>タイトルに「2026年○月号（No.○）」のように号名を入力します。</li><li>下部の「Figures号の情報」で、発刊日、頒価、表紙、紹介文、目次を入力します。</li><li>まず「下書き保存」を押し、「プレビュー」で表示を確認します。</li><li>問題がなければ「公開」し、「最新号として表示」にチェックを入れます。</li></ol>
		<p><strong>大切な注意：</strong>一度公開した内容は、修正前に「リビジョン（変更履歴）」を確認できます。前の号を上書きせず、必ず「新しい号を追加」から作成してください。</p>
	</div>
	<?php
}

function figures_starter_register_metaboxes() {
	add_meta_box( 'figures-issue-details', 'Figures号の情報', 'figures_starter_render_issue_metabox', 'figures_issue', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'figures_starter_register_metaboxes' );

/**
 * Presents essential data fields in a fixed order so editors can fill in the page without composing layout blocks.
 */
function figures_starter_render_issue_metabox( $post ) {
	wp_nonce_field( 'figures_starter_save_issue', 'figures_starter_issue_nonce' );
	$fields = array(
		'number' => get_post_meta( $post->ID, '_figures_issue_number', true ),
		'publication_date' => get_post_meta( $post->ID, '_figures_publication_date', true ),
		'price' => get_post_meta( $post->ID, '_figures_price', true ),
		'summary' => get_post_meta( $post->ID, '_figures_summary', true ),
		'purchase_label' => get_post_meta( $post->ID, '_figures_purchase_label', true ),
		'purchase_url' => get_post_meta( $post->ID, '_figures_purchase_url', true ),
		'is_current' => get_post_meta( $post->ID, '_figures_is_current', true ),
		'toc' => get_post_meta( $post->ID, '_figures_toc', true ),
	);
	$toc = is_array( $fields['toc'] ) ? $fields['toc'] : array();
	?>
	<style>.figures-field-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px;max-width:900px}.figures-field-grid label{display:block;font-weight:600;margin-bottom:5px}.figures-field-grid input,.figures-field-grid textarea{width:100%}.figures-field-grid .wide{grid-column:1/-1}.figures-toc-table{width:100%;border-collapse:collapse;max-width:1000px}.figures-toc-table th,.figures-toc-table td{padding:7px;border:1px solid #dcdcde;text-align:left}.figures-toc-table input{width:100%}@media(max-width:650px){.figures-field-grid{grid-template-columns:1fr}}</style>
	<p>上から順に入力してください。目次は未使用の行を空欄のままにして構いません。</p>
	<div class="figures-field-grid">
		<div><label for="figures_issue_number">号数</label><input id="figures_issue_number" name="figures_issue_number" type="text" value="<?php echo esc_attr( $fields['number'] ); ?>" placeholder="例：No.1"></div>
		<div><label for="figures_publication_date">発刊日</label><input id="figures_publication_date" name="figures_publication_date" type="date" value="<?php echo esc_attr( $fields['publication_date'] ); ?>"></div>
		<div><label for="figures_price">頒価</label><input id="figures_price" name="figures_price" type="text" value="<?php echo esc_attr( $fields['price'] ); ?>" placeholder="例：500円"></div>
		<div><label for="figures_purchase_label">購入案内のボタン文言</label><input id="figures_purchase_label" name="figures_purchase_label" type="text" value="<?php echo esc_attr( $fields['purchase_label'] ); ?>" placeholder="例：購入について問い合わせる"></div>
		<div class="wide"><label for="figures_purchase_url">購入案内のリンク先</label><input id="figures_purchase_url" name="figures_purchase_url" type="url" value="<?php echo esc_attr( $fields['purchase_url'] ); ?>" placeholder="購入ページのURL。未定なら空欄のままにします。"></div>
		<div class="wide"><label for="figures_summary">今号の紹介文</label><textarea id="figures_summary" name="figures_summary" rows="4" placeholder="100～250字を目安に、今号の紹介を入力します。"> <?php echo esc_textarea( $fields['summary'] ); ?></textarea></div>
		<div class="wide"><label><input name="figures_is_current" type="checkbox" value="1" <?php checked( $fields['is_current'], '1' ); ?>> この号を「最新号」としてトップページに表示する</label><p class="description">新しい号でチェックを入れると、以前の最新号は自動的にバックナンバーへ移ります。</p></div>
	</div>
	<h3>目次</h3>
	<table class="figures-toc-table"><thead><tr><th>ジャンル</th><th>作品名</th><th>著者名</th><th>頁</th></tr></thead><tbody>
	<?php for ( $i = 0; $i < 12; $i++ ) : $row = isset( $toc[ $i ] ) ? $toc[ $i ] : array(); ?>
		<tr><td><input name="figures_toc[<?php echo esc_attr( $i ); ?>][genre]" value="<?php echo esc_attr( isset( $row['genre'] ) ? $row['genre'] : '' ); ?>"></td><td><input name="figures_toc[<?php echo esc_attr( $i ); ?>][title]" value="<?php echo esc_attr( isset( $row['title'] ) ? $row['title'] : '' ); ?>"></td><td><input name="figures_toc[<?php echo esc_attr( $i ); ?>][author]" value="<?php echo esc_attr( isset( $row['author'] ) ? $row['author'] : '' ); ?>"></td><td><input name="figures_toc[<?php echo esc_attr( $i ); ?>][page]" value="<?php echo esc_attr( isset( $row['page'] ) ? $row['page'] : '' ); ?>" placeholder="p.2"></td></tr>
	<?php endfor; ?>
	</tbody></table>
	<p class="description">表紙は、右側（または下部）の「アイキャッチ画像を設定」から登録してください。</p>
	<?php
}

function figures_starter_save_issue( $post_id ) {
	if ( ! isset( $_POST['figures_starter_issue_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['figures_starter_issue_nonce'] ) ), 'figures_starter_save_issue' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) { return; }
	if ( ! current_user_can( 'edit_post', $post_id ) ) { return; }

	$text_fields = array( 'figures_issue_number' => '_figures_issue_number', 'figures_publication_date' => '_figures_publication_date', 'figures_price' => '_figures_price', 'figures_purchase_label' => '_figures_purchase_label' );
	foreach ( $text_fields as $request_key => $meta_key ) {
		update_post_meta( $post_id, $meta_key, isset( $_POST[ $request_key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $request_key ] ) ) : '' );
	}
	update_post_meta( $post_id, '_figures_summary', isset( $_POST['figures_summary'] ) ? sanitize_textarea_field( wp_unslash( $_POST['figures_summary'] ) ) : '' );
	update_post_meta( $post_id, '_figures_purchase_url', isset( $_POST['figures_purchase_url'] ) ? esc_url_raw( wp_unslash( $_POST['figures_purchase_url'] ) ) : '' );

	$is_current = isset( $_POST['figures_is_current'] ) ? '1' : '';
	update_post_meta( $post_id, '_figures_is_current', $is_current );
	if ( '1' === $is_current ) {
		$others = get_posts( array( 'post_type' => 'figures_issue', 'post_status' => 'any', 'posts_per_page' => -1, 'post__not_in' => array( $post_id ), 'meta_key' => '_figures_is_current', 'meta_value' => '1', 'fields' => 'ids' ) );
		foreach ( $others as $other_id ) { update_post_meta( $other_id, '_figures_is_current', '' ); }
	}

	$clean_toc = array();
	if ( isset( $_POST['figures_toc'] ) && is_array( $_POST['figures_toc'] ) ) {
		foreach ( wp_unslash( $_POST['figures_toc'] ) as $row ) {
			$clean_row = array( 'genre' => sanitize_text_field( isset( $row['genre'] ) ? $row['genre'] : '' ), 'title' => sanitize_text_field( isset( $row['title'] ) ? $row['title'] : '' ), 'author' => sanitize_text_field( isset( $row['author'] ) ? $row['author'] : '' ), 'page' => sanitize_text_field( isset( $row['page'] ) ? $row['page'] : '' ) );
			if ( implode( '', $clean_row ) !== '' ) { $clean_toc[] = $clean_row; }
		}
	}
	update_post_meta( $post_id, '_figures_toc', $clean_toc );
}
add_action( 'save_post_figures_issue', 'figures_starter_save_issue' );

function figures_starter_admin_columns( $columns ) {
	return array( 'cb' => $columns['cb'], 'title' => '号名', 'figures_number' => '号数', 'figures_date' => '発刊日', 'figures_current' => '最新号', 'date' => '公開日' );
}
add_filter( 'manage_figures_issue_posts_columns', 'figures_starter_admin_columns' );

function figures_starter_render_admin_columns( $column, $post_id ) {
	if ( 'figures_number' === $column ) { echo esc_html( get_post_meta( $post_id, '_figures_issue_number', true ) ); }
	if ( 'figures_date' === $column ) { echo esc_html( get_post_meta( $post_id, '_figures_publication_date', true ) ); }
	if ( 'figures_current' === $column ) { echo '1' === get_post_meta( $post_id, '_figures_is_current', true ) ? '<strong>最新号</strong>' : '—'; }
}
add_action( 'manage_figures_issue_posts_custom_column', 'figures_starter_render_admin_columns', 10, 2 );

function figures_starter_enqueue_styles() {
	if ( is_singular( 'figures_issue' ) || is_post_type_archive( 'figures_issue' ) || is_post_type_archive( 'figures_news' ) || ( is_page() && has_shortcode( get_post_field( 'post_content', get_queried_object_id() ), 'figures_home' ) ) ) {
		wp_enqueue_style( 'figures-site-starter', FIGURES_STARTER_URL . 'assets/figures-site.css', array(), FIGURES_STARTER_VERSION );
		wp_enqueue_style( 'figures-site-refinements', FIGURES_STARTER_URL . 'assets/figures-site-refinements.css', array( 'figures-site-starter' ), FIGURES_STARTER_VERSION );
	}
}
add_action( 'wp_enqueue_scripts', 'figures_starter_enqueue_styles' );

function figures_starter_get_current_issue() {
	$issues = get_posts( array( 'post_type' => 'figures_issue', 'post_status' => 'publish', 'posts_per_page' => 1, 'meta_key' => '_figures_is_current', 'meta_value' => '1' ) );
	if ( $issues ) { return $issues[0]; }
	$fallback = get_posts( array( 'post_type' => 'figures_issue', 'post_status' => 'publish', 'posts_per_page' => 1, 'orderby' => 'date', 'order' => 'DESC' ) );
	return $fallback ? $fallback[0] : null;
}

function figures_starter_format_date( $date ) {
	return $date ? wp_date( 'Y年n月j日', strtotime( $date ) ) : '発刊日を準備中';
}

function figures_starter_render_toc( $issue_id ) {
	$toc = get_post_meta( $issue_id, '_figures_toc', true );
	if ( ! is_array( $toc ) || ! $toc ) { return; }
	echo '<div class="figures-toc"><p class="figures-kicker">CONTENTS</p><table><thead><tr><th>ジャンル</th><th>作品名</th><th>著者名</th><th>頁</th></tr></thead><tbody>';
	foreach ( $toc as $row ) { echo '<tr><td>' . esc_html( $row['genre'] ) . '</td><td>' . esc_html( $row['title'] ) . '</td><td>' . esc_html( $row['author'] ) . '</td><td>' . esc_html( $row['page'] ) . '</td></tr>'; }
	echo '</tbody></table></div>';
}

/**
 * Public homepage: dynamically fills with content where available and uses clear, non-fictional empty states otherwise.
 */
function figures_starter_home_shortcode() {
	$current = figures_starter_get_current_issue();
	$issues = new WP_Query( array( 'post_type' => 'figures_issue', 'post_status' => 'publish', 'posts_per_page' => 4, 'post__not_in' => $current ? array( $current->ID ) : array() ) );
	$news = new WP_Query( array( 'post_type' => 'figures_news', 'post_status' => 'publish', 'posts_per_page' => 3 ) );
	$issue_archive = get_post_type_archive_link( 'figures_issue' );
	$news_archive = get_post_type_archive_link( 'figures_news' );
	ob_start();
	?>
	<div class="figures-site">
		<nav class="figures-nav" aria-label="Figures 内のページ"><a href="#latest">最新号</a><a href="#archive">バックナンバー</a><a href="#news">お知らせ</a><a href="#about">Figuresとは</a><a href="#contact">お問い合わせ</a></nav>
		<section class="figures-hero"><div class="figures-rail"><span>FIGURES / LITERARY JOURNAL</span><i>01</i></div><div><p class="figures-kicker">文芸誌</p><h1>Figures</h1><p class="figures-deck">言葉のかたちを丁寧に蓄積し、<br>次の読者へ手渡すための文芸誌。</p><p class="figures-status">● <?php echo $current ? '最新号を公開中' : '公開準備中'; ?></p></div><div class="figures-hero-art"><span>FORM / SILENCE / TRACE</span></div></section>
		<section class="figures-block figures-latest" id="latest"><div class="figures-index"><span>01</span><i>Latest issue</i></div><div class="figures-block-main"><p class="figures-kicker">最新号</p><?php if ( $current ) : ?><h2><?php echo esc_html( get_the_title( $current->ID ) ); ?></h2><div class="figures-issue-display"><div class="figures-cover"><?php echo get_the_post_thumbnail( $current->ID, 'large', array( 'alt' => esc_attr( get_the_title( $current->ID ) . ' 表紙' ) ) ); ?><span>表紙を登録</span></div><div class="figures-issue-copy"><p><?php echo esc_html( figures_starter_format_date( get_post_meta( $current->ID, '_figures_publication_date', true ) ) ); ?>　<?php echo esc_html( get_post_meta( $current->ID, '_figures_price', true ) ); ?></p><div><?php echo wp_kses_post( wpautop( get_post_meta( $current->ID, '_figures_summary', true ) ) ); ?></div><a class="figures-button" href="<?php echo esc_url( get_permalink( $current->ID ) ); ?>">目次をひらく</a></div></div><?php else : ?><h2>次の一冊を、<br><em>静かに迎える。</em></h2><div class="figures-empty-issue"><div class="figures-empty-spine">FIGURES — NEW ISSUE</div><div><p class="figures-empty-label">掲載準備中</p><h3>最新号の情報を<br>ここに掲載します。</h3><p>表紙、号名、発刊日、頒価、紹介文、目次を登録すると、最新号として自動表示されます。</p></div></div><?php endif; ?></div><aside class="figures-editor-note"><p>FOR EDITORS</p><h3>更新に必要なのは<br>六つの入力項目です。</h3><ol><li>表紙画像</li><li>号名・号数</li><li>発刊日・頒価</li><li>紹介文</li><li>目次</li><li>購入案内</li></ol><small>入力後は「プレビュー」→「公開」の二段階で確認できます。</small></aside></section>
		<section class="figures-archive" id="archive"><div class="figures-archive-head"><p class="figures-kicker">バックナンバー</p><h2>時間をさかのぼり、<br>言葉に出会う。</h2></div><div class="figures-archive-grid"><?php if ( $issues->have_posts() ) : while ( $issues->have_posts() ) : $issues->the_post(); ?><article><a href="<?php the_permalink(); ?>" class="figures-mini-cover"><?php if ( has_post_thumbnail() ) { the_post_thumbnail( 'medium', array( 'alt' => esc_attr( get_the_title() . ' 表紙' ) ) ); } else { ?><span>Figures</span><?php } ?></a><h3><?php the_title(); ?></h3><p><?php echo esc_html( get_post_meta( get_the_ID(), '_figures_publication_date', true ) ); ?></p></article><?php endwhile; wp_reset_postdata(); else : ?><?php for ( $i = 1; $i <= 4; $i++ ) : ?><article><div class="figures-mini-cover figures-placeholder"><span>SHELF <?php echo esc_html( str_pad( (string) $i, 2, '0', STR_PAD_LEFT ) ); ?></span><b>挿入待ち</b><i><?php echo esc_html( str_pad( (string) $i, 2, '0', STR_PAD_LEFT ) ); ?></i></div><h3>第<?php echo esc_html( $i ); ?>号</h3><p>刊行情報を登録後に表示</p></article><?php endfor; ?><?php endif; ?></div><p class="figures-note">一冊ごとに表紙、発刊情報、目次、購入案内を追加できます。</p><?php if ( $issues->found_posts > 0 ) : ?><a class="figures-text-link" href="<?php echo esc_url( $issue_archive ); ?>">バックナンバー一覧へ →</a><?php endif; ?></section>
		<section class="figures-block figures-news" id="news"><div class="figures-index"><span>03</span><i>News</i></div><div class="figures-news-heading"><p class="figures-kicker">お知らせ</p><h2>編集部からの<br>小さな便り。</h2></div><div class="figures-news-list"><?php if ( $news->have_posts() ) : while ( $news->have_posts() ) : $news->the_post(); ?><a href="<?php the_permalink(); ?>"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'Y.m.d' ) ); ?></time><span><?php the_title(); ?></span><b>→</b></a><?php endwhile; wp_reset_postdata(); else : ?><div class="figures-news-empty"><strong>お知らせはまだありません。</strong><span>発刊や会合のお知らせを、必要なときに追加できます。</span></div><?php endif; ?></div></section>
		<section class="figures-about" id="about"><div class="figures-about-symbol">⌇</div><div><p class="figures-kicker">Figuresとは</p><h2>まだ余白の頁に、<br><em>これからの言葉を。</em></h2><p>Figuresは、作品と批評を丁寧に読み、言葉の新しい輪郭を見つめるための文芸誌です。このページには、創刊の趣旨、編集方針、発行情報を掲載します。</p><small>「Figuresとは」は固定ページの本文から、いつでも書き換えられます。</small></div></section>
		<section class="figures-contact" id="contact"><div><p class="figures-kicker">お問い合わせ</p><h2>編集部へ<br>おたずねください。</h2><p>冊子の購入、会員・寄稿について、掲載内容に関するお問い合わせは、専用フォームで受け付けます。</p><span class="figures-contact-button">お問い合わせ先を準備中</span><small>公開時に受信先メールアドレスと個人情報取扱いを設定します。</small></div><div class="figures-contact-art"><span>CONTACT / 04</span></div></section>
	</div>
	<?php
	return ob_get_clean();
}
add_shortcode( 'figures_home', 'figures_starter_home_shortcode' );

/**
 * Simple single issue template uses the active theme's header/footer and Figures components.
 */
function figures_starter_template_include( $template ) {
	if ( is_singular( 'figures_issue' ) ) {
		$plugin_template = FIGURES_STARTER_PATH . 'templates/single-figures_issue.php';
		if ( file_exists( $plugin_template ) ) { return $plugin_template; }
	}
	return $template;
}
add_filter( 'template_include', 'figures_starter_template_include' );
