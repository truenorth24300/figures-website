<?php
/**
 * Style: "余白の書架" — a calm, readable single-issue page that lets the active WordPress theme retain its global shell.
 */
get_header();
while ( have_posts() ) : the_post();
	$issue_id = get_the_ID();
	$number = get_post_meta( $issue_id, '_figures_issue_number', true );
	$publication_date = get_post_meta( $issue_id, '_figures_publication_date', true );
	$price = get_post_meta( $issue_id, '_figures_price', true );
	$summary = get_post_meta( $issue_id, '_figures_summary', true );
	$purchase_label = get_post_meta( $issue_id, '_figures_purchase_label', true );
	$purchase_url = get_post_meta( $issue_id, '_figures_purchase_url', true );
	?>
	<main class="figures-single"><p class="figures-kicker">FIGURES / ISSUE <?php echo esc_html( $number ); ?></p><p><a class="figures-text-link" href="<?php echo esc_url( home_url( '/figures/' ) ); ?>">← Figures トップへ</a></p><div class="figures-single-grid"><div class="figures-cover figures-single-cover"><?php if ( has_post_thumbnail() ) { the_post_thumbnail( 'large', array( 'alt' => esc_attr( get_the_title() . ' 表紙' ) ) ); } else { ?><span>表紙画像を準備中</span><?php } ?></div><article><h1><?php the_title(); ?></h1><p class="figures-single-meta"><?php echo esc_html( figures_starter_format_date( $publication_date ) ); ?>　<?php echo esc_html( $price ); ?></p><?php if ( $summary ) : ?><div class="figures-single-summary"><?php echo wp_kses_post( wpautop( $summary ) ); ?></div><?php endif; ?><?php figures_starter_render_toc( $issue_id ); ?><?php if ( $purchase_label ) : ?><p><a class="figures-button" href="<?php echo esc_url( $purchase_url ? $purchase_url : home_url( '/figures/#contact' ) ); ?>"><?php echo esc_html( $purchase_label ); ?></a></p><?php endif; ?></article></div></main>
	<?php
endwhile;
get_footer();

