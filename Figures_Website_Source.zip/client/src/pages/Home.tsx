/**
 * Style: "余白の書架" — the public home template uses editorial whitespace and shelf-like
 * sections. Every empty state describes the next editorial action instead of inventing content.
 */
import { ArrowDownRight, ArrowUpRight, BookOpenText, Mail, Menu, MoveRight, Newspaper, X } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const logoUrl = "/manus-storage/figures-logo-mark_0187aa6b.png";
const heroImageUrl = "/manus-storage/figures-hero-object_3eb830f7.jpg";
const contactImageUrl = "/manus-storage/figures-contact-stilllife_80f33ce8.jpg";

const navItems = [
  { label: "最新号", href: "#latest" },
  { label: "バックナンバー", href: "#archive" },
  { label: "お知らせ", href: "#news" },
  { label: "Figuresとは", href: "#about" },
  { label: "お問い合わせ", href: "#contact" },
];

function Brand() {
  return (
    <a className="brand" href="#top" aria-label="Figures トップへ">
      <img src={logoUrl} alt="Figuresのシンボルマーク" />
      <span>Figures</span>
    </a>
  );
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="site-shell" id="top">
      <header className="site-header">
        <div className="header-inner">
          <a className="parent-link" href="https://digital-research.co.jp/" target="_blank" rel="noreferrer">
            Digital Research <ArrowUpRight size={13} strokeWidth={1.7} />
          </a>
          <Brand />
          <nav className="desktop-nav" aria-label="Figures 内のページ">
            {navItems.map((item) => <a key={item.href} href={item.href}>{item.label}</a>)}
          </nav>
          <button className="menu-toggle" onClick={() => setMenuOpen((open) => !open)} aria-expanded={menuOpen} aria-controls="mobile-menu" aria-label="メニューを開く">
            {menuOpen ? <X size={23} /> : <Menu size={23} />}
          </button>
        </div>
        {menuOpen && (
          <nav className="mobile-nav" id="mobile-menu" aria-label="Figures 内のページ">
            {navItems.map((item, index) => <a key={item.href} href={item.href} onClick={() => setMenuOpen(false)}><span>0{index + 1}</span>{item.label}<ArrowDownRight size={18} /></a>)}
          </nav>
        )}
      </header>

      <main>
        <section className="hero" aria-labelledby="hero-title">
          <div className="spine-rail"><span>FIGURES / LITERARY JOURNAL</span><i>01</i></div>
          <div className="hero-copy">
            <p className="eyebrow"><span /> 文芸誌</p>
            <h1 id="hero-title">Figures</h1>
            <p className="hero-deck">言葉のかたちを丁寧に蓄積し、<br />次の読者へ手渡すための文芸誌。</p>
            <div className="hero-status"><span className="status-dot" />公開準備中 <em>CONTENTS IN PREPARATION</em></div>
            <a className="text-link" href="#latest">公開予定の構成を見る <MoveRight size={19} /></a>
          </div>
          <div className="hero-art" aria-label="Figuresのための抽象的なイメージ">
            <span className="image-index">— 01</span>
            <img src={heroImageUrl} alt="青と深緑の抽象的な紙片を配したFiguresのイメージ" />
            <p>FORM / SILENCE / TRACE</p>
          </div>
        </section>

        <section className="latest-section" id="latest" aria-labelledby="latest-title">
          <div className="section-index"><span>01</span><span>Latest issue</span></div>
          <div className="section-main">
            <div className="section-heading">
              <p className="eyebrow"><span /> 最新号</p>
              <h2 id="latest-title">次の一冊を、<br /><em>静かに迎える。</em></h2>
            </div>
            <div className="issue-empty-card">
              <div className="issue-spine">FIGURES&nbsp;&nbsp;—&nbsp;&nbsp;NEW ISSUE</div>
              <div className="empty-issue-body">
                <BookOpenText size={34} strokeWidth={1.2} />
                <p className="empty-tag">掲載準備中</p>
                <h3>最新号の情報を<br />ここに掲載します。</h3>
                <p>表紙、号名、発刊日、頒価、紹介文、目次を登録すると、最新号として自動表示されます。</p>
              </div>
              <div className="empty-foot"><span>Issue number</span><b>—</b><span>Publication date</span><b>—</b></div>
            </div>
          </div>
          <aside className="editor-note">
            <p className="note-index">FOR EDITORS</p>
            <h3>更新に必要なのは<br />六つの入力項目です。</h3>
            <ol>
              <li><span>01</span>表紙画像</li><li><span>02</span>号名・号数</li><li><span>03</span>発刊日・頒価</li><li><span>04</span>紹介文</li><li><span>05</span>目次</li><li><span>06</span>購入案内</li>
            </ol>
            <p>入力後は「プレビュー」→「公開」の二段階で確認できます。</p>
          </aside>
        </section>

        <section className="archive-section" id="archive" aria-labelledby="archive-title">
          <div className="archive-topline"><span>02 / Archive</span><span>BACK NUMBERS</span></div>
          <div className="archive-intro">
            <p className="eyebrow"><span /> バックナンバー</p>
            <h2 id="archive-title">時間をさかのぼり、<br />言葉に出会う。</h2>
          </div>
          <div className="shelf-grid">
            {["第1号", "第2号", "第3号", "第4号"].map((issue, index) => (
              <article className="shelf-item" key={issue}>
                <div className="shelf-placeholder"><span>SHELF&nbsp;&nbsp;{String(index + 1).padStart(2, "0")}</span><b>挿入待ち</b><i>{String(index + 1).padStart(2, "0")}</i></div>
                <div><p>{issue}</p><span>刊行情報を登録後に表示</span></div>
              </article>
            ))}
          </div>
          <p className="archive-caption">一冊ごとに表紙、発刊情報、目次、購入案内を追加できます。初期公開時は、登録済みの号だけがこの棚に並びます。</p>
        </section>

        <section className="news-section" id="news" aria-labelledby="news-title">
          <div className="section-index"><span>03</span><span>News</span></div>
          <div className="news-heading"><p className="eyebrow"><span /> お知らせ</p><h2 id="news-title">編集部からの<br />小さな便り。</h2></div>
          <div className="news-empty-list">
            <div className="empty-news-intro"><Newspaper size={28} strokeWidth={1.2} /><p>お知らせは<br /><strong>まだありません。</strong></p></div>
            <div className="news-template-row"><span>発刊のお知らせ</span><i>新号の公開時に記録します</i><ArrowDownRight size={19} /></div>
            <div className="news-template-row"><span>会合・催しのご案内</span><i>日程確定後に記録します</i><ArrowDownRight size={19} /></div>
            <div className="news-template-row"><span>編集部より</span><i>必要な折に記録します</i><ArrowDownRight size={19} /></div>
          </div>
        </section>

        <section className="about-section" id="about" aria-labelledby="about-title">
          <div className="about-mark"><img src={logoUrl} alt="" /></div>
          <div className="about-copy"><p className="eyebrow"><span /> Figuresとは</p><h2 id="about-title">まだ余白の頁に、<br /><em>これからの言葉を。</em></h2><p>Figuresは、作品と批評を丁寧に読み、言葉の新しい輪郭を見つめるための文芸誌です。このページには、創刊の趣旨、編集方針、発行情報を掲載します。</p><p className="about-small">「Figuresとは」は管理画面の固定ページから、いつでも書き換えられます。</p></div>
          <div className="about-rule"><span>FIGURES</span><i>—</i><span>ABOUT THE JOURNAL</span></div>
        </section>

        <section className="contact-section" id="contact" aria-labelledby="contact-title">
          <div className="contact-content"><p className="eyebrow"><span /> お問い合わせ</p><h2 id="contact-title">編集部へ<br />おたずねください。</h2><p>冊子の購入、会員・寄稿について、掲載内容に関するお問い合わせは、専用フォームで受け付けます。</p><button type="button" className="contact-button" onClick={() => toast("お問い合わせフォームは現在準備中です。公開時に受信先を設定します。")}><Mail size={19} />お問い合わせ先を準備中</button><p className="contact-note">公開時に受信先メールアドレスと個人情報取扱いを設定します。</p></div>
          <div className="contact-image"><img src={contactImageUrl} alt="便箋と青緑の万年筆を配した静物" /><span>CONTACT / 04</span></div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="footer-brand"><Brand /><p>Literary Journal</p></div>
        <div className="footer-info"><span>© Figures</span><span>Published by Digital Research</span><a href="https://digital-research.co.jp/" target="_blank" rel="noreferrer">デジタルリサーチへ <ArrowUpRight size={13} /></a></div>
      </footer>
    </div>
  );
}
