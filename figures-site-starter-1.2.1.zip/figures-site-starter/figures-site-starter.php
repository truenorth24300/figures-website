<?php
/**
 * Plugin Name: Figures Site Starter
 * Description: 文芸誌Figuresの号管理、無署名ブログ、通信欄を既存WordPressテーマと共存させて管理するプラグインです。
 * Version: 1.2.1
 * Author: Digital Research / Figures
 * Text Domain: figures-site-starter
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'FIGURES_STARTER_VERSION', '1.2.1' );
define( 'FIGURES_STARTER_PATH', plugin_dir_path( __FILE__ ) );
define( 'FIGURES_STARTER_URL', plugin_dir_url( __FILE__ ) );

/**
 * Public data stays in a plugin so it survives changes to the corporate theme.
 */
function figures_starter_register_content_types() {
	register_post_type(
		'figures_issue',
		array(
			'labels' => array(
				'name'          => 'Figures号',
				'singular_name' => 'Figures号',
				'add_new_item'  => 'Figures号を追加',
				'edit_item'     => 'Figures号を編集',
				'view_item'     => '公開ページを表示',
				'menu_name'     => 'Figures号',
			),
			'public'             => true,
			'show_ui'            => true,
			'show_in_menu'       => false,
			'show_in_rest'       => true,
			'has_archive'        => 'figures/backnumber',
			'rewrite'            => array( 'slug' => 'figures/issue', 'with_front' => false ),
			'supports'           => array( 'title', 'thumbnail', 'revisions' ),
			'capability_type'    => array( 'figures_issue', 'figures_issues' ),
			'map_meta_cap'       => true,
			'exclude_from_search'=> false,
		)
	);

	register_post_type(
		'figures_blog',
		array(
			'labels' => array(
				'name'          => 'Figuresブログ',
				'singular_name' => 'Figuresブログ',
				'add_new_item'  => 'ブログ記事を追加',
				'edit_item'     => 'ブログ記事を編集',
				'view_item'     => '公開記事を表示',
				'menu_name'     => 'Figuresブログ',
			),
			'public'             => true,
			'show_ui'            => true,
			'show_in_menu'       => false,
			'show_in_rest'       => true,
			'has_archive'        => 'figures/blog',
			'rewrite'            => array( 'slug' => 'figures/blog', 'with_front' => false ),
			'supports'           => array( 'title', 'editor', 'thumbnail', 'revisions', 'author' ),
			'capability_type'    => array( 'figures_blog', 'figures_blogs' ),
			'map_meta_cap'       => true,
			'exclude_from_search'=> false,
		)
	);
}
add_action( 'init', 'figures_starter_register_content_types' );

function figures_starter_issue_caps() {
	return array(
		'read', 'upload_files',
		'edit_figures_issues', 'publish_figures_issues', 'delete_figures_issues',
		'edit_published_figures_issues', 'delete_published_figures_issues',
		'edit_figures_issue', 'read_figures_issue', 'delete_figures_issue',
	);
}

function figures_starter_blog_caps() {
	return array(
		'read', 'upload_files',
		'edit_figures_blogs', 'publish_figures_blogs', 'delete_figures_blogs',
		'edit_published_figures_blogs', 'delete_published_figures_blogs',
		'edit_figures_blog', 'read_figures_blog', 'delete_figures_blog',
	);
}

/**
 * Two named contributors use individual accounts. Public templates never print author names.
 */
function figures_starter_add_roles_and_capabilities() {
	$editor_caps = array_fill_keys( array_merge( figures_starter_issue_caps(), figures_starter_blog_caps() ), true );
	$editor_caps['edit_others_figures_issues'] = true;
	$editor_caps['delete_others_figures_issues'] = true;
	$editor_caps['edit_others_figures_blogs'] = true;
	$editor_caps['delete_others_figures_blogs'] = true;
	add_role( 'figures_editor', 'Figures事務局', $editor_caps );
	add_role( 'figures_contributor', 'Figures投稿者', array_fill_keys( figures_starter_blog_caps(), true ) );

	$administrator = get_role( 'administrator' );
	if ( $administrator ) {
		foreach ( $editor_caps as $capability => $granted ) {
			$administrator->add_cap( $capability, $granted );
		}
	}
}

function figures_starter_activate() {
	figures_starter_register_content_types();
	figures_starter_add_roles_and_capabilities();
	update_option( 'figures_starter_installed_version', FIGURES_STARTER_VERSION );
	if ( ! get_page_by_path( 'figures' ) ) {
		wp_insert_post(
			array(
				'post_title'   => 'Figures',
				'post_name'    => 'figures',
				'post_status'  => 'publish',
				'post_type'    => 'page',
				'post_content' => '[figures_home]',
			)
		);
	}
	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'figures_starter_activate' );
register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );

/**
 * Plugin updates do not run activation hooks; grant new limited capabilities once after an update.
 */
function figures_starter_maybe_upgrade() {
	if ( get_option( 'figures_starter_installed_version' ) !== FIGURES_STARTER_VERSION ) {
		figures_starter_add_roles_and_capabilities();
		update_option( 'figures_starter_installed_version', FIGURES_STARTER_VERSION );
		flush_rewrite_rules();
	}
}
add_action( 'admin_init', 'figures_starter_maybe_upgrade' );

function figures_starter_admin_menu() {
	add_menu_page( 'Figures 運用', 'Figures 運用', 'edit_figures_issues', 'figures-operation', 'figures_starter_operation_page', 'dashicons-book-alt', 25 );
	add_submenu_page( 'figures-operation', '運用の概要', '運用の概要', 'edit_figures_issues', 'figures-operation', 'figures_starter_operation_page' );
	add_submenu_page( 'figures-operation', '最新号・バックナンバー', '号を管理', 'edit_figures_issues', 'edit.php?post_type=figures_issue' );
	add_submenu_page( 'figures-operation', 'ブログ', 'ブログ', 'edit_figures_blogs', 'edit.php?post_type=figures_blog' );
	add_submenu_page( 'figures-operation', '通信欄', '通信欄', 'manage_options', 'figures-message', 'figures_starter_message_page' );
}
add_action( 'admin_menu', 'figures_starter_admin_menu' );

function figures_starter_operation_page() {
	if ( ! current_user_can( 'edit_figures_issues' ) ) { return; }
	$issues = wp_count_posts( 'figures_issue' );
	$blogs  = wp_count_posts( 'figures_blog' );
	?>
	<div class="wrap">
		<h1>Figures 運用</h1>
		<p>日常の更新は、このメニュー内だけで行えます。テーマ、プラグイン、会社サイトの通常投稿には触れないでください。</p>
		<table class="widefat striped" style="max-width:900px"><thead><tr><th>更新するもの</th><th>開く場所</th><th>現在の公開数</th></tr></thead><tbody>
			<tr><td>最新号・バックナンバー</td><td><a href="<?php echo esc_url( admin_url( 'edit.php?post_type=figures_issue' ) ); ?>">Figures号を開く</a></td><td><?php echo esc_html( (string) $issues->publish ); ?>件</td></tr>
			<tr><td>ブログ</td><td><a href="<?php echo esc_url( admin_url( 'edit.php?post_type=figures_blog' ) ); ?>">Figuresブログを開く</a></td><td><?php echo esc_html( (string) $blogs->publish ); ?>件</td></tr>
			<tr><td>通信欄</td><td><a href="<?php echo esc_url( admin_url( 'admin.php?page=figures-message' ) ); ?>">通信欄設定を開く</a></td><td>Contact Form 7のショートコードを設定</td></tr>
		</tbody></table>
		<h2>投稿者について</h2>
		<p>角谷氏・遠藤氏には個別の「Figures投稿者」アカウントを発行します。ブログは無署名で公開されますが、管理画面には作成者と変更履歴が残ります。</p>
	</div>
	<?php
}

function figures_starter_message_page() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	if ( isset( $_POST['figures_message_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['figures_message_nonce'] ) ), 'figures_save_message' ) ) {
		update_option( 'figures_contact_form_shortcode', sanitize_text_field( wp_unslash( $_POST['figures_contact_form_shortcode'] ?? '' ) ) );
		echo '<div class="notice notice-success"><p>通信欄の設定を保存しました。</p></div>';
	}
	$shortcode = get_option( 'figures_contact_form_shortcode', '' );
	?>
	<div class="wrap"><h1>Figures 通信欄</h1>
		<p>Contact Form 7で作成したフォームのショートコードを入力してください。受信先 <code>landsendlive@gmail.com</code> は、Contact Form 7の「メール」設定のTo欄にだけ設定します。公開ページ・テーマ・GitHubには書かれません。</p>
		<form method="post"><input type="hidden" name="figures_message_nonce" value="<?php echo esc_attr( wp_create_nonce( 'figures_save_message' ) ); ?>">
			<p><label for="figures_contact_form_shortcode"><strong>Contact Form 7 ショートコード</strong></label><br><input class="regular-text code" id="figures_contact_form_shortcode" name="figures_contact_form_shortcode" value="<?php echo esc_attr( $shortcode ); ?>" placeholder="[contact-form-7 id=&quot;123&quot; title=&quot;Figures 通信欄&quot;]"></p>
			<p><button class="button button-primary">保存</button></p>
		</form>
		<h2>フォーム項目</h2><p>お名前、E-mail、通信内容の種類（冊子の希望／Figuresについて／その他）、件名、通信内容、確認用語句「Figures」を設定します。同意チェック欄は設けません。</p>
	</div>
	<?php
}

function figures_starter_add_issue_box() {
	add_meta_box( 'figures-issue-information', 'Figures号の情報', 'figures_starter_issue_box', 'figures_issue', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'figures_starter_add_issue_box' );

function figures_starter_issue_box( $post ) {
	wp_nonce_field( 'figures_save_issue', 'figures_issue_nonce' );
	$number  = get_post_meta( $post->ID, '_figures_number', true );
	$date    = get_post_meta( $post->ID, '_figures_date', true );
	$toc_id  = (int) get_post_meta( $post->ID, '_figures_toc_image', true );
	$pdf_url = get_post_meta( $post->ID, '_figures_pdf_url', true );
	$current = get_post_meta( $post->ID, '_figures_current', true );
	?>
	<style>.figures-meta-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;max-width:900px}.figures-meta-grid label{display:block;font-weight:600;margin-bottom:5px}.figures-meta-grid input{width:100%}.figures-meta-grid .wide{grid-column:1/-1}@media(max-width:650px){.figures-meta-grid{grid-template-columns:1fr}}</style>
	<p>表紙は右側の「アイキャッチ画像」から、目次は下欄から登録します。PDF公開前に、各号の権利確認を行ってください。</p>
	<div class="figures-meta-grid">
		<div><label for="figures_number">号数</label><input id="figures_number" name="figures_number" value="<?php echo esc_attr( $number ); ?>" placeholder="例：No.4"></div>
		<div><label for="figures_date">発行日</label><input id="figures_date" name="figures_date" type="date" value="<?php echo esc_attr( $date ); ?>"></div>
		<div class="wide"><label for="figures_pdf_url">公開PDFのURL</label><input id="figures_pdf_url" name="figures_pdf_url" type="url" value="<?php echo esc_attr( $pdf_url ); ?>" placeholder="メディアライブラリのPDF URL"></div>
		<div class="wide"><label for="figures_toc_image">目次画像</label><input id="figures_toc_image" name="figures_toc_image" type="hidden" value="<?php echo esc_attr( (string) $toc_id ); ?>"><button type="button" class="button figures-select-toc">目次画像を選択</button> <span class="figures-toc-preview"><?php echo $toc_id ? wp_get_attachment_image( $toc_id, 'thumbnail', false, array( 'style' => 'vertical-align:middle;max-height:80px;width:auto' ) ) : '未選択'; ?></span></div>
		<div class="wide"><label><input name="figures_current" type="checkbox" value="1" <?php checked( $current, '1' ); ?>> この号を最新号として表示する</label></div>
	</div>
	<script>jQuery(function($){$('.figures-select-toc').on('click',function(e){e.preventDefault();const frame=wp.media({title:'目次画像を選択',button:{text:'この画像を使う'},multiple:false});frame.on('select',function(){const item=frame.state().get('selection').first().toJSON();$('#figures_toc_image').val(item.id);$('.figures-toc-preview').html('<img src="'+item.url+'" style="vertical-align:middle;max-height:80px;width:auto">');});frame.open();});});</script>
	<?php
}

function figures_starter_save_issue( $post_id ) {
	if ( ! isset( $_POST['figures_issue_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['figures_issue_nonce'] ) ), 'figures_save_issue' ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) { return; }
	update_post_meta( $post_id, '_figures_number', sanitize_text_field( wp_unslash( $_POST['figures_number'] ?? '' ) ) );
	update_post_meta( $post_id, '_figures_date', sanitize_text_field( wp_unslash( $_POST['figures_date'] ?? '' ) ) );
	update_post_meta( $post_id, '_figures_pdf_url', esc_url_raw( wp_unslash( $_POST['figures_pdf_url'] ?? '' ) ) );
	update_post_meta( $post_id, '_figures_toc_image', absint( $_POST['figures_toc_image'] ?? 0 ) );
	$current = isset( $_POST['figures_current'] ) ? '1' : '';
	update_post_meta( $post_id, '_figures_current', $current );
	if ( '1' === $current ) {
		$others = get_posts( array( 'post_type' => 'figures_issue', 'post_status' => 'any', 'posts_per_page' => -1, 'post__not_in' => array( $post_id ), 'meta_key' => '_figures_current', 'meta_value' => '1', 'fields' => 'ids' ) );
		foreach ( $others as $other_id ) { update_post_meta( $other_id, '_figures_current', '' ); }
	}
}
add_action( 'save_post_figures_issue', 'figures_starter_save_issue' );

function figures_starter_admin_scripts( $hook ) {
	if ( 'post.php' === $hook || 'post-new.php' === $hook ) { wp_enqueue_media(); }
}
add_action( 'admin_enqueue_scripts', 'figures_starter_admin_scripts' );

function figures_starter_current_issue() {
	$issues = get_posts( array( 'post_type' => 'figures_issue', 'post_status' => 'publish', 'posts_per_page' => 1, 'meta_key' => '_figures_current', 'meta_value' => '1' ) );
	if ( $issues ) { return $issues[0]; }
	$fallback = get_posts( array( 'post_type' => 'figures_issue', 'post_status' => 'publish', 'posts_per_page' => 1, 'orderby' => 'date', 'order' => 'DESC' ) );
	return $fallback ? $fallback[0] : null;
}

function figures_starter_issue_date( $issue_id ) {
	$date = get_post_meta( $issue_id, '_figures_date', true );
	return $date ? wp_date( 'Y年n月j日', strtotime( $date ) ) : '';
}

function figures_starter_issue_folio( $issue_id, $type ) {
	if ( 'cover' === $type ) {
		return get_the_post_thumbnail( $issue_id, 'large', array( 'alt' => get_the_title( $issue_id ) . ' 表紙' ) );
	}
	$toc_id = (int) get_post_meta( $issue_id, '_figures_toc_image', true );
	return $toc_id ? wp_get_attachment_image( $toc_id, 'large', false, array( 'alt' => get_the_title( $issue_id ) . ' 目次' ) ) : '';
}

function figures_starter_home_shortcode() {
	$current = figures_starter_current_issue();
	$issues  = new WP_Query( array( 'post_type' => 'figures_issue', 'post_status' => 'publish', 'posts_per_page' => 3, 'post__not_in' => $current ? array( $current->ID ) : array(), 'orderby' => 'meta_value', 'meta_key' => '_figures_date', 'order' => 'DESC' ) );
	$blogs   = new WP_Query( array( 'post_type' => 'figures_blog', 'post_status' => 'publish', 'posts_per_page' => 5 ) );
	$form    = get_option( 'figures_contact_form_shortcode', '' );
	ob_start();
	?>
	<div class="figures-site">
		<nav class="figures-nav" aria-label="Figures内のページ"><a href="#latest">最新号</a><a href="#archive">バックナンバー</a><a href="#blog">ブログ</a><a href="#message">通信欄</a></nav>
		<section class="figures-hero"><aside class="figures-rail"><span>FIGURES / REVUE LITTÉRAIRE</span><i>01</i></aside><div class="figures-hero-copy"><h1>Figures</h1><p class="figures-subtitle">revue littéraire</p><div class="figures-history"><div><b>沿革</b><span>2025年（令和8年）4月30日創刊</span></div><div><b>同人</b><span>・角谷 有一　・遠藤 雅樹</span></div><div><b>発行情報</b><span>編集発行人：遠藤 雅樹<br>発行所：（有）デジタルリサーチ<br>印刷：東海共同印刷</span></div></div></div><aside class="figures-blog-panel" id="blog"><h2>ブログ</h2><ul><?php if ( $blogs->have_posts() ) : while ( $blogs->have_posts() ) : $blogs->the_post(); ?><li><a href="<?php the_permalink(); ?>"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'Y.m.d' ) ); ?></time><span><?php the_title(); ?></span></a></li><?php endwhile; wp_reset_postdata(); endif; ?></ul><?php if ( $blogs->found_posts > 5 ) : ?><a class="figures-blog-more" href="<?php echo esc_url( get_post_type_archive_link( 'figures_blog' ) ); ?>">ブログ一覧へ　→</a><?php endif; ?></aside></section>
		<section class="figures-section figures-latest" id="latest"><aside class="figures-index"><b>02</b><span>LATEST ISSUE</span></aside><div class="figures-main"><div class="figures-section-head"><div><p>LATEST ISSUE</p><h2>最新号</h2></div><?php if ( $current ) : ?><small><?php echo esc_html( figures_starter_issue_date( $current->ID ) ); ?>　<?php echo esc_html( get_post_meta( $current->ID, '_figures_number', true ) ); ?></small><?php endif; ?></div><?php if ( $current ) : ?><div class="figures-spread"><figure><figcaption>表紙</figcaption><?php echo wp_kses_post( figures_starter_issue_folio( $current->ID, 'cover' ) ); ?></figure><figure><figcaption>目次</figcaption><?php echo wp_kses_post( figures_starter_issue_folio( $current->ID, 'toc' ) ); ?></figure></div><?php $pdf = get_post_meta( $current->ID, '_figures_pdf_url', true ); if ( $pdf ) : ?><p><a class="figures-link" target="_blank" rel="noopener" href="<?php echo esc_url( $pdf ); ?>">PDFを開く　→</a></p><?php endif; ?><p class="figures-note">冊子ご希望の場合は、通信欄からお申し込みください。</p><?php else : ?><p class="figures-note">最新号の情報を準備中です。</p><?php endif; ?></div></section>
		<section class="figures-archive" id="archive"><div class="figures-archive-top"><span>03 / ARCHIVE</span><span>BACK NUMBERS</span></div><h2>バックナンバー</h2><div class="figures-archive-list"><?php if ( $issues->have_posts() ) : while ( $issues->have_posts() ) : $issues->the_post(); $pdf = get_post_meta( get_the_ID(), '_figures_pdf_url', true ); ?><article><div class="figures-mini-spread"><figure><?php echo wp_kses_post( figures_starter_issue_folio( get_the_ID(), 'cover' ) ); ?></figure><figure><?php echo wp_kses_post( figures_starter_issue_folio( get_the_ID(), 'toc' ) ); ?></figure></div><div class="figures-issue-meta"><div><h3><?php the_title(); ?></h3><p><?php echo esc_html( figures_starter_issue_date( get_the_ID() ) ); ?></p></div><?php if ( $pdf ) : ?><a class="figures-link" target="_blank" rel="noopener" href="<?php echo esc_url( $pdf ); ?>">PDFを開く　→</a><?php endif; ?></div></article><?php endwhile; wp_reset_postdata(); else : ?><p class="figures-note">バックナンバーを登録すると、ここに表紙と目次が表示されます。</p><?php endif; ?></div></section>
		<section class="figures-section figures-message" id="message"><aside class="figures-index"><b>04</b><span>MESSAGE</span></aside><div class="figures-message-copy"><p>FIGURES / MESSAGE</p><h2>お問い合わせ</h2><p>冊子のご希望、ご感想、連絡等は、通信欄からお寄せください。</p></div><div class="figures-form-panel"><h3>通信欄</h3><p>こちらよりお問い合わせください。</p><?php echo $form ? do_shortcode( $form ) : '<p class="figures-form-notice">通信欄のフォームは事務局で準備中です。</p>'; ?></div></section>
	</div>
	<?php
	return ob_get_clean();
}
add_shortcode( 'figures_home', 'figures_starter_home_shortcode' );

function figures_starter_enqueue_assets() {
	$queried_id = get_queried_object_id();
	if ( is_singular( 'figures_issue' ) || is_singular( 'figures_blog' ) || is_post_type_archive( 'figures_issue' ) || is_post_type_archive( 'figures_blog' ) || figures_starter_is_home_page() ) {
		wp_enqueue_style( 'figures-site-starter', FIGURES_STARTER_URL . 'assets/figures-site.css', array(), FIGURES_STARTER_VERSION );
	}
}
add_action( 'wp_enqueue_scripts', 'figures_starter_enqueue_assets' );

/**
 * The Figures landing page must never inherit the corporate site's sidebar layout.
 */
function figures_starter_is_home_page() {
	$queried_id = get_queried_object_id();
	return is_page() && $queried_id && has_shortcode( get_post_field( 'post_content', $queried_id ), 'figures_home' );
}

function figures_starter_templates( $template ) {
	if ( figures_starter_is_home_page() ) { return FIGURES_STARTER_PATH . 'templates/page-figures-home.php'; }
	if ( is_singular( 'figures_blog' ) ) { return FIGURES_STARTER_PATH . 'templates/single-figures-blog.php'; }
	if ( is_post_type_archive( 'figures_blog' ) ) { return FIGURES_STARTER_PATH . 'templates/archive-figures-blog.php'; }
	if ( is_singular( 'figures_issue' ) ) { return FIGURES_STARTER_PATH . 'templates/single-figures-issue.php'; }
	return $template;
}
add_filter( 'template_include', 'figures_starter_templates' );
